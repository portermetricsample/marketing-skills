/**
 * Report controls — LOGIC/WIRING ONLY (restyle to taste). Date range + period
 * comparison. These are the controls users expect by default; keep them.
 * Wire them to useDateRange() so the active range mirrors into the URL (deep-link
 * / share / PDF).
 */
import type { Preset, Range } from '../lib/useReport';
import type { AccountUniverse } from '../lib/porter';

const PRESETS: { id: Exclude<Preset, 'custom'>; label: string }[] = [
  { id: '7d', label: 'Last 7 days' },
  { id: '30d', label: 'Last 30 days' },
  { id: '90d', label: 'Last 90 days' },
  { id: '6m', label: 'Last 6 months' },
];

export function DateRangeControl({
  preset,
  setPreset,
  custom,
  setCustom,
}: {
  preset: Preset;
  setPreset: (p: Preset) => void;
  custom: Range;
  setCustom: (r: Range) => void;
}) {
  return (
    <div className="control">
      <div className="chips" role="group" aria-label="Date range">
        {PRESETS.map((p) => (
          <button key={p.id} className={preset === p.id ? 'chip chip--on' : 'chip'} onClick={() => setPreset(p.id)}>
            {p.label}
          </button>
        ))}
        <button className={preset === 'custom' ? 'chip chip--on' : 'chip'} onClick={() => setPreset('custom')}>
          Custom
        </button>
      </div>
      {preset === 'custom' && (
        <div className="date-inputs">
          <input type="date" value={custom.start} max={custom.end} onChange={(e) => setCustom({ ...custom, start: e.target.value })} />
          <span>to</span>
          <input type="date" value={custom.end} min={custom.start} onChange={(e) => setCustom({ ...custom, end: e.target.value })} />
        </div>
      )}
    </div>
  );
}

/**
 * Source-account selector (SELECT_MULTIPLE) — LOGIC/WIRING ONLY (restyle to taste).
 * Lets the viewer choose WHICH source accounts the report's queries run against.
 * It is NOT a filter: it scopes the query to the chosen source accounts (bounded
 * by the report's accounts_used). Pair it with useAccounts() and feed the hook's
 * `accounts` into your query base.
 *
 * Multi-source: by default it groups every connector into one selector (sections
 * per data source). For a SEPARATE selector per data source, render one
 * <AccountSelector> per connector with `connectors={['facebook-ads']}` etc.
 */
export function AccountSelector({
  universe,
  selectedIds,
  setSelectedIds,
  connectors,
  label = 'Accounts',
}: {
  universe: AccountUniverse;
  selectedIds: string[];
  setSelectedIds: (ids: string[]) => void;
  /** Restrict to these connectors (one selector per source). Omit for all. */
  connectors?: string[];
  label?: string;
}) {
  const groups = connectors ?? universe.connectors;
  const toggle = (id: string) =>
    setSelectedIds(selectedIds.includes(id) ? selectedIds.filter((x) => x !== id) : [...selectedIds, id]);

  return (
    <div className="control account-selector" role="group" aria-label={label}>
      <span className="control-label">{label}</span>
      {groups.map((connector) => {
        const ids = universe.by_connector[connector] ?? [];
        const accounts = universe.accounts.filter((a) => ids.includes(a.id));
        if (accounts.length === 0) return null;
        return (
          <div key={connector} className="account-group">
            {groups.length > 1 && <div className="account-group-title">{connector}</div>}
            {accounts.map((a) => (
              <label key={a.id} className="account-option">
                <input type="checkbox" checked={selectedIds.includes(a.id)} onChange={() => toggle(a.id)} />
                <span>{a.name || a.id}</span>
              </label>
            ))}
          </div>
        );
      })}
    </div>
  );
}

export function ComparisonToggle({ compare, setCompare }: { compare: boolean; setCompare: (v: boolean) => void }) {
  return (
    <button
      className={compare ? 'toggle toggle--on' : 'toggle'}
      role="switch"
      aria-checked={compare}
      onClick={() => setCompare(!compare)}
      title="Compare vs the previous period of equal length"
    >
      <span className="toggle-dot" /> Compare vs previous period
    </button>
  );
}

/**
 * Dimension-value filter dropdown (e.g. filter the report to one campaign) —
 * LOGIC/WIRING ONLY (restyle to taste). Pair it with useFilter() + useDimensionValues():
 *
 *   const { value, setValue, filters } = useFilter('campaign_name');
 *   const opts = useDimensionValues('campaign_name', { accounts, range });
 *   const q = useReportQuery({ connector: 'facebook-ads', accounts, fields, filters }, range);
 *   <FilterSelect label="Campaign" value={value} setValue={setValue} options={opts.values} />
 *
 * The "All" option clears the filter (server returns all rows). Picking a value sets a
 * REAL server-side filter (reaches GetData as dimensionsFilters) — do NOT filter rows in
 * JS. For a multi-select filter use `useFilter(field, 'in')` + checkboxes (see AccountSelector).
 */
export function FilterSelect({
  label,
  value,
  setValue,
  options,
  allLabel = 'All',
}: {
  label: string;
  value: string | string[] | null;
  setValue: (v: string | null) => void;
  options: string[];
  allLabel?: string;
}) {
  const current = Array.isArray(value) ? (value[0] ?? '') : (value ?? '');
  return (
    <div className="control filter-select">
      <span className="control-label">{label}</span>
      <select
        className="filter-select-input"
        value={current}
        onChange={(e) => setValue(e.target.value === '' ? null : e.target.value)}
        aria-label={label}
      >
        <option value="">{allLabel}</option>
        {options.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>
    </div>
  );
}
