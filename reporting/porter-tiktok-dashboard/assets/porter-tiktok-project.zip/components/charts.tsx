/**
 * Interactive charts — LOGIC/WIRING ONLY (restyle to taste). Dependency-free SVG
 * with hover tooltips. Colors come from CSS vars so they follow the theme. Feel
 * free to swap these for a vendored charting lib (self-hosted — no CDN under the
 * report CSP).
 */
import { useRef, useState } from 'react';

type Point = { label: string; value: number };
type Fmt = (n: number) => string;

const defaultFmt: Fmt = (n) => new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(n);

export function LineChart({
  points,
  color = 'var(--accent)',
  height = 180,
  format = defaultFmt,
}: {
  points: Point[];
  color?: string;
  height?: number;
  format?: Fmt;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  if (!points.length) return <div className="state-empty">No data for this range.</div>;

  const W = 960;
  const H = height;
  const pad = 10;
  const vals = points.map((p) => p.value);
  const max = Math.max(1, ...vals);
  const min = Math.min(0, ...vals);
  const x = (i: number) => pad + (i / Math.max(points.length - 1, 1)) * (W - pad * 2);
  const y = (v: number) => pad + ((max - v) / (max - min || 1)) * (H - pad * 2);
  const line = points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
  const area = `${line} L${x(points.length - 1).toFixed(1)},${H - pad} L${x(0).toFixed(1)},${H - pad} Z`;

  const onMove = (e: React.MouseEvent) => {
    const el = wrapRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const rel = ((e.clientX - rect.left) / rect.width) * W;
    const i = Math.round(((rel - pad) / (W - pad * 2)) * (points.length - 1));
    setHover(Math.max(0, Math.min(points.length - 1, i)));
  };

  const gid = `lg-${Math.round(max)}-${points.length}`;
  return (
    <div ref={wrapRef} className="chart-wrap" onMouseMove={onMove} onMouseLeave={() => setHover(null)}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label="line chart" preserveAspectRatio="none">
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28" />
            <stop offset="100%" stopColor={color} stopOpacity="0.02" />
          </linearGradient>
        </defs>
        <path d={area} fill={`url(#${gid})`} />
        <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        {hover != null && (
          <>
            <line x1={x(hover)} y1={pad} x2={x(hover)} y2={H - pad} stroke="var(--muted)" strokeWidth="1" strokeDasharray="3 3" />
            <circle cx={x(hover)} cy={y(points[hover].value)} r="4" fill={color} stroke="var(--panel)" strokeWidth="2" />
          </>
        )}
      </svg>
      {hover != null && (
        <div
          className="chart-tip"
          style={{ left: `${(x(hover) / W) * 100}%`, transform: `translateX(${hover > points.length / 2 ? '-105%' : '5%'})` }}
        >
          <div className="chart-tip-label">{points[hover].label}</div>
          <div className="chart-tip-value">{format(points[hover].value)}</div>
        </div>
      )}
    </div>
  );
}

export function BarChart({ points, format = defaultFmt, max: maxProp }: { points: Point[]; format?: Fmt; max?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  if (!points.length) return <div className="state-empty">No data for this range.</div>;
  const max = Math.max(1, maxProp ?? Math.max(...points.map((p) => p.value)));
  return (
    <div className="bars">
      {points.map((p, i) => (
        <div key={i} className={`bar-row${hover === i ? ' is-hover' : ''}`} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
          <div className="bar-label" title={p.label}>
            {p.label}
          </div>
          <div className="bar-track">
            <div className="bar-fill" style={{ width: `${(p.value / max) * 100}%` }} />
          </div>
          <div className="bar-value">{format(p.value)}</div>
        </div>
      ))}
    </div>
  );
}
