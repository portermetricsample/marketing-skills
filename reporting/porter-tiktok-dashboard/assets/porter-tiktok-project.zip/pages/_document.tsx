import { Html, Head, Main, NextScript } from 'next/document';

/**
 * Self-hosted BRAND fonts (Bricolage Grotesque, Hanken Grotesk, IBM Plex Mono).
 *
 * The report runs under a strict CSP (`font-src <origin> data:`) with an injected
 * `<base href>`, so these @font-face `url()`s are RELATIVE — they resolve against
 * the base (→ the report bundle), never a network origin. The woff2 ship in
 * `public/fonts/` (Next copies them to `out/fonts/`). They live inline in the
 * document head (not in a CSS file) so the url resolves against the base href,
 * not the stylesheet's `/_next/static/css/` location.
 *
 * globals.css wires them via --font-sans / --font-display / --font-mono. RESTYLE
 * freely, but keep the brand typography — do NOT fall back to a system stack.
 */
const FONT_CSS = `
@font-face{font-family:'Bricolage Grotesque';font-style:normal;font-weight:400;font-display:swap;src:url("fonts/bricolage-grotesque-400.woff2") format("woff2");}
@font-face{font-family:'Bricolage Grotesque';font-style:normal;font-weight:600;font-display:swap;src:url("fonts/bricolage-grotesque-600.woff2") format("woff2");}
@font-face{font-family:'Bricolage Grotesque';font-style:normal;font-weight:700;font-display:swap;src:url("fonts/bricolage-grotesque-700.woff2") format("woff2");}
@font-face{font-family:'Bricolage Grotesque';font-style:normal;font-weight:800;font-display:swap;src:url("fonts/bricolage-grotesque-800.woff2") format("woff2");}
@font-face{font-family:'Hanken Grotesk';font-style:normal;font-weight:400;font-display:swap;src:url("fonts/hanken-grotesk-400.woff2") format("woff2");}
@font-face{font-family:'Hanken Grotesk';font-style:normal;font-weight:500;font-display:swap;src:url("fonts/hanken-grotesk-500.woff2") format("woff2");}
@font-face{font-family:'Hanken Grotesk';font-style:normal;font-weight:600;font-display:swap;src:url("fonts/hanken-grotesk-600.woff2") format("woff2");}
@font-face{font-family:'Hanken Grotesk';font-style:normal;font-weight:700;font-display:swap;src:url("fonts/hanken-grotesk-700.woff2") format("woff2");}
@font-face{font-family:'IBM Plex Mono';font-style:normal;font-weight:500;font-display:swap;src:url("fonts/ibm-plex-mono-500.woff2") format("woff2");}
`;

export default function Document() {
  return (
    <Html>
      <Head>
        <style dangerouslySetInnerHTML={{ __html: FONT_CSS }} />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
